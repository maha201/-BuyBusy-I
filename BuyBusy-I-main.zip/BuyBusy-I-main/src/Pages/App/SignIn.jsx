// Imports
import Login from "../../Components/Login/Login"

// Page for the signin the user.
export default function SignIn(){
    // Returning Jsx
    return(
        <Login/>   
    )
}