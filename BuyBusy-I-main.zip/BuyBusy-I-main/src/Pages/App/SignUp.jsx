// Imports
import Register from "../../Components/Signup Component/Signup"

// Page for the signup the user.
export default function SignUp(){
    // Returning Jsx
    return(
        <Register/>
    )
}